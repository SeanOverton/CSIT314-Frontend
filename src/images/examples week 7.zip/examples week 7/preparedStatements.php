<!DOCTYPE html>
<html>
<head>
<title>prepared statements</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php


    include ("inc_dbconnect.php");
    
try {

    // prepare and bind
    $stmt = mysqli_prepare($conn, "INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sss", $fname, $lname, $email);

    // set parameters and execute
    $fname = "John1";
    $lname = "Doe1";
    $email = "john@example.com";
    mysqli_stmt_execute($stmt);

    $fname = "Mary2";
    $lname = "Moe2";
    $email = "mary@example.com";
    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    $sql = "SELECT firstname, lastname, email FROM MyGuests"; //ORDER by firstname
    $stmt = mysqli_prepare($conn, $sql);

    // execute statement
    mysqli_stmt_execute($stmt);
//---
/*
    // bind result variables
    mysqli_stmt_bind_result($stmt, $fname, $lname, $email);
    // fetch values
    while (mysqli_stmt_fetch($stmt))
    {
        echo $fname. " " . $lname . " - " . $email . "<br />";
    }
 */
//---

    //fetch the resultset
    echo "with resultset <br >";
    $qRes = mysqli_stmt_get_result($stmt);
    while (($row = mysqli_fetch_row($qRes)) != FALSE)
    {
        echo $row[0]. " -" . $row[1] . " - " . $row[2] . "<br />";
    }

    // close statement
    mysqli_stmt_close($stmt);
}
catch (mysqli_sql_exception $e){
        die("Unable to execute the query" . mysqli_errno($conn) . mysqli_error($conn));
}
    
mysqli_close($conn);

?>
</body>
</html>
