<!DOCTYPE html>
<html>
<head>
<title>example</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

$servername = "localhost";
$username = "root";
$password = "xx"; //"mysql"


try{
    $conn = mysqli_connect($servername, $username, $password);
    echo "<p>Connection successful</p>\n";
}
catch (mysqli_sql_exception $e)
{
    die("Connection failed: ". mysqli_connect_errno(). " - " . mysqli_connect_error());
}

//mysqli_close($conn);



try{
    // Create connection
    //$conn = mysqli_connect($servername, $username, $password);

	echo "<p>MySQL client version: " . mysqli_get_client_info() . "</p>\n";
	echo "<p>MySQL connection: " . mysqli_get_host_info($conn) . "</p>\n";
	echo "<p>MySQL protocol version: " . mysqli_get_proto_info($conn) . "</p>\n";
	echo "<p>MySQL server version: "	. mysqli_get_server_info($conn) . "</p>\n";
}
catch (mysqli_sql_exception $e) {
     die("Connection failed: ". mysqli_connect_errno(). " - " . mysqli_connect_error());
 }

mysqli_close($conn);
 


//********** before PHP 8.1 **********
/*
// Create connection
$conn = @mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) { //(mysqli_errno() !=0)
    die("Connection failed: ". mysqli_connect_errno(). " - " . mysqli_connect_error());
}
 */

?>
</form>
</body>
</html>

