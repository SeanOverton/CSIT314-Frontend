<!DOCTYPE html>
<html>
<head>
<title>Databases</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>records</h1>
<?php
    include ("inc_dbconnect.php");


    $sql = "INSERT INTO MyGuests(firstname,lastname, email) VALUES ('Elena100', 'Vlahu100', 'evg@gmail.com')";
    try {
        mysqli_query($conn, $sql);
        $GuestID = mysqli_insert_id($conn);
        echo "Your ID is $GuestID <br />";
    }
    catch (mysqli_sql_exception $e) {
        echo "Unable to insert the the record";
    }
 

//******* pre PHP8.1 **********
/*
    $qResult = @mysqli_query($conn, $sql);
    if ($qResult === FALSE)
        echo "Unable to insert the the record";
    else {
            $GuestID = mysqli_insert_id($conn);
            echo "Your ID is $GuestID <br />";
    }
 */
//*************************


    $sql = "INSERT INTO MyGuests " .
     " (firstname, lastname, email) " .
     " VALUES " .
     " ('Tom100', 'Hon100', 'tt@gmail.com'), " .
     " ('Tara100', 'Davis100', 'tara@gmail.com'), " .
     " ('Kate100', 'Smith100', 'kate@gmail.com')";

    try {
        mysqli_query($conn, $sql);
        echo "Successfully added the records.<br />";
        echo mysqli_info($conn);
     }
    catch (mysqli_sql_exception $e) {
      die("Unable to execute the query" . mysqli_errno($conn) . mysqli_error($conn));
    }



    $id=1;
    $email = "EEEEEEE@gmail.com";
    $sql = "UPDATE MyGuests SET email='" . $email . "' WHERE id=" . $id;
    try {
        mysqli_query($conn, $sql);
        echo "Record updated successfully <br />";
    }
    catch (mysqli_sql_exception $e) {
        die("Error in updating: " . mysqli_error($conn) . "<br />");
    }

        
    $id=3;
    $sql = "DELETE FROM MyGuests where id=". $id;

    try {
        mysqli_query($conn, $sql);
        echo mysqli_affected_rows($conn) . " row(s) were deleted.<br />";
    }
    catch (mysqli_sql_exception $e) {
        echo "error" . mysqli_error($conn);
    }
 


/*
    $sql = "SELECT * FROM MyGuests";
    
    try {
        $qResult = mysqli_query($conn, $sql);
        echo mysqli_num_rows($qResult) . " row(s) in the table, with " . mysqli_num_fields($qResult) . " fields in each row. <br />";
        //while (($row = mysqli_fetch_row($qResult)) != FALSE)
        while (($row = mysqli_fetch_assoc($qResult)) != FALSE)
        {
            //echo $row[0] . "-" . $row[1] . "-" . $row[2] . "-" . $row[3]  . "<br />";
            //echo $row['id'] . "-" . $row['firstname'] . "-" . $row['lastname'] . "-" . $row['email']  . "<br />";
            print_r($row);
            echo "<br />";
            }
        mysqli_free_result($qResult);
    }
    catch (mysqli_sql_exception $e) {
        die("error");
    }
*/

    mysqli_close($conn);
    
?>
</body>
</html>
