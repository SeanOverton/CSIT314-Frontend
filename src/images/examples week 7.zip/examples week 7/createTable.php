<!DOCTYPE html>
<html>
<head>
<title>Create Table</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

// Create connection
try {
$conn = mysqli_connect($servername, $username, $password, $dbname); }
catch ( mysqli_sql_exception $e) {
    die("Connection failed: " . mysqli_connect_error());}

//create table
$sql = "CREATE TABLE MyGuests1 (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        firstname VARCHAR(30) NOT NULL,
        lastname VARCHAR(30) NOT NULL,
        email VARCHAR(50))";
try {
    mysqli_query($conn, $sql);
    echo "Table MyGuests1 created successfully";
}
catch (mysqli_sql_exception $e){
     die("Error creating table: " . mysqli_error($conn));}

mysqli_close($conn);
?>
</body>
</html>
